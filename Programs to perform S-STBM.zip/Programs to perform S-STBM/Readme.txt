Readme.txt
The name of the main program is Workplace.m
This program produce 10 realizations with 1000 calibrated lines each for the first synthetic example presented in the paper.
The OF is defined by the directional asymmetry (Horning & Bardossy, 2018)

