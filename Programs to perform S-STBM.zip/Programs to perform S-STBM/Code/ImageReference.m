function [zref,POS,Zobs,meanzref]=ImageReference(dimx,dimy,nbHD)
%%field size 
%model and C mac for covardm.m
%model=[1 1 1 0 ; 4 20 40 0]; c=[0.2;0.8];
model=[1 1 ; 4 50 ]; c=[0.2;0.8];
%seed for fix random number
seed=50;
%number of rectangle for reference picture
nrec=3;
% slope of line for asymmetry
pente=(sum(c)/dimx)*15;

%creation of asymmetric field of reference
k=fftma(model,c,seed,1,dimx,1,dimy,1);

%k(:,3)=0;
Zref=ImRef_dl(k(:,1:2),k(:,3),nrec,pente,seed,0,0); clear nrec; clear pente;
zref=[]; zref=reshape(Zref{1,1},[],1);

clear Zref;

k(:,3)=(k(:,3)-min(k(:,3)))/(max(k(:,3))-min(k(:,3)));
%%%%%
p=haltonset(2);

POS=(ceil(p(50:50+nbHD-1,1)*dimx)+(ceil(p(50:50+nbHD-1,2)*dimx)-1)*dimy);
Zobs=[k(POS,1:2),zref(POS)];

imagesc(reshape(zref,[dimx,dimy]))
hold on 
plot(k(POS,2),k(POS,1),'ok');
colorbar()

clear model; clear c; clear p; clear seed;

    