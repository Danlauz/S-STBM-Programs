function [dist]=Dist_h(nx,ny)

X=[1:1:2*nx-1];
Y=[1:1:2*ny-1];

X=ones(2*nx-1,2*ny-1).*X';
Y=ones(2*nx-1,2*ny-1).*Y;

dist=sqrt((X-nx).^2+(Y-ny).^2);