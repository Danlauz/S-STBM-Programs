function [Z,ErrFinal,Ufinal]=TourBandSpecOpt(nx,ny,nz,model,c,nl,nbsim,zref,Pos)
x0=grille3(1,nx,1,1,ny,1,1,nz,1);

   
%Target directional asymmetry (OF)
[AssObj,nhObj]=varioFFT2D_dl( x0(:,[1  2]) , zref , [8,3] , 0 , 0 );
ObjOpt={2,AssObj,nhObj,3 };     

%Anamorphosis
Y(:,:)=anamor([x0,zref]);
Yobs=Y(Pos,[1 2 3 5]);

%matrix of covariance of observed data for the post-conditioning
k=covardm(x0(Pos,1:3),x0(Pos,1:3),model,c);
ki=inv(k);
k0=covardm(x0(Pos,1:3),x0,model,c);
    
%1- Calculation of f1(s) and F1
[F1,s,rot,cx]=DensSpec1Ddl(x0,model,c);

%2-Random number between 0-1 and define ul
% draw random probabilities
ul1=zeros(max(1000,nl),size(F1,2));
for k=1:size(F1,2)
    p=rand(max(1000,nl),1);
    ul1(1:max(1000,nl),k)=interp1(F1{k},s{k},p); % interpolate ul from p and cum
end
%3-random line generation
z=VanCorput(max(1000,nl));    % Van Corput sequence
z1=cell(2,1);
for k=1:size(F1,2)
    %4- scalar product of line z with density line ul
    z1{k}=ul1(1:max(1000,nl),k).*z;
end
ErrFinal=ones(max(1000,nl),nbsim);
Ufinal=ones(max(1000,nl),nbsim);
Z=zeros(size(x0,1),nbsim);
parfor j=1:nbsim  %parfor for iterations in parallel on worker
    tic
    zsim=zeros(size(x0,1),1);  ysim=zeros(size(x0,1),1);
    Err=ones(max(1000,nl),1);  U=zeros(max(1000,nl),1);
    Err0=zeros(length(ObjOpt),1);
    
    rng('default')
    rng(j+nbsim);
    i=0;     
    
    while i< max(1000,nl)       
      i=i+1 ; 
        if  i<=max(1,(1000-nl))%0.5*nl
            Uinit = rand(1)*2*pi;
            for k=1:size(F1,2)
                ysim=ysim+ sqrt(2)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ Uinit);
            end
            y= postcond( Yobs , [x0(Pos,:) , ysim(Pos,:)/sqrt(i)], [x0 ,ysim/sqrt(i)] , 1 , ki ,k0 );
            U(i)=Uinit;
            zfin=anamorinv(Y,y(:,end));
                        
            if i==1
                Err0=ErrOpt(x0,zfin(:,2),ObjOpt,Err0);
            else
                Err(i)=ErrOpt(x0,zfin(:,2),ObjOpt,Err0);
            end
            
        else            
            options=optimset('MaxIter',5,'TolX',10^-8,'Display','off');
            func = @(Uopt) OptErr(x0,ysim,Uopt,c,cx,rot,z1,Yobs,Pos,ObjOpt,i,Err0,Y,ki,k0);
            Uopt = fminbnd(func, 0, 2*pi,options);
            for k=1:size(F1,2)
                ysim= ysim+ sqrt(2)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ Uopt);
            end
            y= postcond( Yobs , [x0(Pos,:) , ysim(Pos,:)/sqrt(i)], [x0 ,ysim/sqrt(i)] , 1 , ki ,k0 );
            zfin=anamorinv(Y,y(:,end));
            Err(i)=ErrOpt(x0,zfin(:,2),ObjOpt,Err0);            
            U(i)=Uopt;
        end        
        %[j,i]
       zsim=zfin(:,2);
    end
    time=toc;
    fprintf('Realization #%d completed in %.2f seconds\n',j,time);
    Ufinal(:,j)=U;
    ErrFinal(:,j)=Err;
    Z(:,j)=zsim;
end

function [error]=OptErr(x0,ysim,U,c,cx,rot,z1,Yobs,Pos,ObjOpt,j,Err0,Y,ki,k0)
for k=1:size(rot,2)
    ysim=ysim+ sqrt(2)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(j,:)'+ U);
end
y= postcond( Yobs , [x0(Pos,:) , ysim(Pos,:)/sqrt(j)], [x0 ,ysim/sqrt(j)] , 1 , ki ,k0 );
zfin=anamorinv(Y,y(:,end));
zsim=zfin(:,2);
error=ErrOpt(x0,zsim,ObjOpt,Err0);
