function [Z]=ImRef_dl(c,z,nrec,a,seed,categ,display)
% Function to compute an asymmetric reference image based on a simulation 
% like fftma. The image is separated into a few rectangles. Subsequently, 
% an pseudo-Ambartuzian process is applied through a linear equation on the
% x-axis.
%
% INPUT : 
%
% c        n by d     matrix of coordinates (regular grid)
% z        n by nvar  matrix of values for the variables. Each line is
%                     associated with the corresponding line vector of
%                     coordinates in the c matrix, and each column corresponds
%                     to a different variable.
%                     Missing values are indicated by NaN
%                     IMPORTANT: At a point, either all variables are observed or all are missing

% nrec     1x1        number of rectangle
% a        1x1        slope of the line ( choose approx. sum(c)/dimx/nrec for not losing the stochastic effect)
% categ    boolean    tells if the variables are categorical (set to 1) or not
%                     (set to 0, default)
% display  boolean    tells if a plot must be displayed (set to 1) or not
%                     (set to 0, default)%                     
% OUTPUT :
%
% Z       nvar by nvar cell array of 1 by 1 of the reference image.


%
% Author: Dany Lauzon - 2018/09/01
% Modified from varioFFT3D_dm.m written by D. Marcotte, dmarcotte@mail.polymtl.ca 

rng('default')
rng(seed);

if nargin<7,
    display=0;
end;
if nargin<6,
    categ=0;
end;

[n_nodes,nvar]=size(z);
if categ,
    nvar=length(unique(z(~isnan(z))));
end;


%%% Finding the parameters of the grid

minc=min(c);
maxc=max(c);

for i=1:size(c,2),
    dum1=diff(unique(c(:,i)));
    if isempty(dum1)
        dc(i)=1;
    else
        dc(i)=dum1(1);
    end
end;

nc=((maxc-minc)./dc)+1;

%%% Reformatting the data

if categ,
    idnan=isnan(z);
    zc=zeros(n_nodes,nvar);
    for i=1:nvar,
        zc(z==i,i)=1;
        zc(idnan,i)=nan;       % to keep the nan in the computation
    end;
    z=zc;
    clear zc;
end;

Z=cell(1,nvar);

if length(nc)==1
    nc=[nc 1];
end
for i=1:nvar,
   Z{1,i}=reshape(z(:,i),nc);
end;

%Initialization matrix of asymmetry 
[u,v]=size(Z{1,1});

if v<nrec
    errordlg('To much rectangle for the the size of the simulation (need nrec<nx)')
else 
    if nrec<1 || mod(nrec,1)~=0 
        errordlg('nrec must be a non-zero integer')
    end
end

A=[];
%same spacing for the rectangle
%x=floor((0:1/(nrec):1).*v);
%spacing of rectangle random
x=sort(floor([0,rand(1,nrec-1),1].*u));
for i=1:length(x)-1    
    A=[A , 0:(x(i+1)-x(i)-1)];  
end
A=(A-mean(A))*a;
 for j=1:nvar
     for i=1:u
         Z{1,j}(i,:)=A+Z{1,j}(i,:);
     end
 end
Z{1,1}(:,:)=(Z{1,1}(:,:)-min(min(Z{1,1}(:,:))))/(max(max(Z{1,1}(:,:)))-min(min(Z{1,1}(:,:))));
% % Display graph

if display & (length(size(Z))<3) % if display and we are in 2D
    figure
            imagesc(Z{1,1})
            title(['Reference image']);
            axis equal
            shading flat;     
            colorbar
end;

