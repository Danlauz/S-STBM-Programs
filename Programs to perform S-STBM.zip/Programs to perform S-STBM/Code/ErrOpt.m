function [ERRSUM]=ErrOpt(x0,zsim,num,Err0)

%%% Finding the parameters of the grid

minc=min(x0);
maxc=max(x0);
dc=zeros(size(x0,2),0);
for i=1:size(x0,2)
    dum1=diff(unique(x0(:,i)));
    if isempty(dum1)
        dc(i)=1;
    else
        dc(i)=dum1(1);
    end
end

nc=((maxc-minc)./dc)+1;

if length(nc)==3
    nx=nc(1);  ny=nc(2);  nz=nc(3);
elseif length(nc)==2
    nx=nc(1);  ny=nc(2);  nz=1;
elseif length(nc)==1
    nx=nc(1);  ny=1;      nz=1;
end

%initialization parameters
zsim=zsim+rand(nx*ny*nz,1)/1000000;
err=zeros(1,size(num,1));
for i=1:size(num,1)
    switch num{i,1}
        case 1 %Variogram
            VarObj=num{i,2};
            nhObj=num{i,3};
            [ghsimYvar]=varioFFT2D_dl( x0(:,[1  2]) , zsim , 1 , 0 , 0 );
            err(i)= erreur(VarObj,nhObj,ghsimYvar,nx,ny);
        case 2 %Asymmetry
            AssObj=num{i,2};
            nhObj=num{i,3};
            expo=num{i,4};
            [ghsimYass]=varioFFT2D_dl( x0(:,[1  2]) , zsim , [8,expo] , 0 , 0 );
            err(i)= erreur(AssObj,nhObj,ghsimYass,nx,ny);
        case 3 %Histogram
            xobj=num{i,2};
            yobj=num{i,3};
            [y,x]=ecdf(zsim);
            err(i)= mean(sqrt((y-yobj).^2+(x-xobj).^2));%immse(y,yobj)+immse(x,xobj);
        case 4 %Moving Average
            %%%walker lake /4, champs gaussien /6
            id1ref1=num{i,2};
            id1ref2=num{i,3};
            I=num{i,4};
            div=num{i,5};
            id=reshape(zsim,[nx,ny])>I;
            id11=conv(mean(id)  , ones(1,floor(nx/div))/floor(nx/div),'same');
            id12=conv(mean(transpose(id))  , ones(1,floor(ny/div))/floor(ny/div),'same');
            err(i)=immse(id11,id1ref1)+immse(id12,id1ref2);
        case 5 %cumulant order 3 (2D only)
            
            upx=floor((3*nx-1)/2);
            upy=floor((3*ny-1)/2);
            downx=ceil((nx+1)/2);
            downy=ceil((ny+1)/2);
            
            cum3ref=num{i,2}; ref=cum3ref{1,1}(:,:);
            hi=num{i,3};
            hj=num{i,4};
            
            cum3Sim=varioFFT2D_dl( x0(:,[1  2]) , zsim , [13,hi,hj] , 0 , 0 );
            sim=cum3Sim{1,1}(:,:);
            dh=Dist_h(size(ref,1),size(ref,2));
            %dh=dh(nx:1:end,ny:1:end);
            err(i)= mean(sqrt (   (ref(~isnan(ref))-sim(~isnan(ref))).^2./(1+dh(~isnan(ref)).^0)), 'all');
            
        case 6 %target histogram from GoShort
            histrefy=num{i,2};
            histrefx=num{i,3};
            g=num{i,4};
            icode=num{i,5};
            dist=GoShort(reshape(zsim,[nx,ny]),g,icode);            
            [histy,histx]=ecdf(reshape(dist+rand(nx,nx)/1000,[],1));            
           
            err(i)= mean(mean(sqrt((histrefy-histy).^2+(histrefx-histx).^2)));
            
        case 7 %Cumulant 1D from a 2D or 3D field.
            cumref=num{i,2};            
            icode=num{i,3};
            if icode==1
            cumsim=Cum3ViaBispec(x0,zsim,1);
            end
            if icode==2
                cumsim=Cum3ViaBispec(x0,reshape(reshape(zsim,[nx,ny])',[1,nx*ny]),1);
            end
            err(i)=sqrt( mean( (cumref(~isnan(cumref))-cumsim(~isnan(cumref))).^2 ));
        case 8 %KS test.
            bzref=num{i,2};
            icode=num{i,3};
            seuil=quantile(zsim,0.7);
            a=zeros(nx*ny,1);
            a= (zsim>=seuil);
            a=reshape(a,[nx,ny]);
            BW=bwconncomp(a);
            [fref,xref] = ecdf(bzref);
            if icode==1
                bzsim=regionprops('Table',BW,'Area');
                [fsim,xsim] = ecdf(bzsim.Area);                
            end
            if icode==2
                bzsim=regionprops('Table',BW,'MajorAxisLength');
                [fsim,xsim] = ecdf(bzsim.MajorAxisLength);               
            end
            if icode==3
                bzsim=regionprops('Table',BW,'Eccentricity');
                [fsim,xsim] = ecdf(bzsim.Eccentricity);               
            end
            if icode==4
                bzsim=regionprops('Table',BW,'Solidity');
                [fsim,xsim] = ecdf(bzsim.Solidity);               
            end
            if icode==5
                bzsim=regionprops('Table',BW,'Circularity');
                [fsim,xsim] = ecdf(bzsim.Circularity);               
            end
            f1=interp1(xref(2:end),fref(2:end),xsim(2:end),'previous','extrap');
            f1(isnan(f1))=0;
            err(i)=sqrt(mean((fsim(2:end)-f1).^2));
        otherwise
            warning('No case for the number %i',num{i,1})
    end
end
if sum(Err0)==0
    ERRSUM=err;
else
    ERRSUM=sum((err./Err0))/size(num,1);
end
function error=erreur(gh1,nh1,gh2,nx,ny)
%selection of middle section
upx=floor((3*nx-1)/2);
upy=floor((3*ny-1)/2);
downx=ceil((nx+1)/2);
downy=ceil((ny+1)/2);

%Selection of the middle window
GH1{1,1}=gh1{1,1}(downx:1:upx, downy:1:upy);
GH2{1,1}=gh2{1,1}(downx:1:upx, downy:1:upy);
NH1=nh1(downx:1:upx, downy:1:upy);

error=sqrt(mean((GH2{1,1}(NH1(:,:)~=0)-GH1{1,1}(NH1(:,:)~=0)).^2));