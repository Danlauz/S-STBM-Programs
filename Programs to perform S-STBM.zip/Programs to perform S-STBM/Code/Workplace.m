% Simply runs Workplace from Matlab command window. 
% This program produce 10 realizations with 2000 calibrated lines 
% each for the first synthetic example presented in the paper
% with the OF define by the directional asymmetry. 

%% Initialization section
model=[1 1 1 1 0 0 0; 4 275 40 1 0 0 0]; c=[0.045;1.5]; %variogram model from varioFFT2D_dl.m and covardm.m
nl=1000; %number of lines to simulate
nbsim=100; %number of realization performed
nx=100; ny=100; nz=1; %dimension of the field (fix nz=1)
nbHD=50; %number of HD data (random selection)
[zref,Pos,Zobs]=ImageReference(nx,ny,nbHD); %reference field
x0=grille3(1,nx,1,1,ny,1,1,nz,1); %grid
Zobs=[x0(Pos,1),x0(Pos,2),ones(size(Zobs,1),1),zref(Pos)]; %position of HD
%% Simulation section
%No optimization
zsimNotOpt=TourBandSpec(nx,ny,nz,model,c,nl,nbsim,zref,Pos); 
% Optimization
zsim=TourBandSpecOpt(nx,ny,nz,model,c,nl,nbsim,zref,Pos);

%% Plot of realizations and reference

figure(1); 
imagesc(reshape((zsim(:,1)),[nx,ny]));
hold on
plot(x0(Pos,2),x0(Pos,1),'ok');
colorbar(); 
caxis([0 1]);
title('Realization calibrated')
colormap jet
figure(2); 
imagesc(reshape((zsimNotOpt(:,1)),[nx,ny]));
hold on
plot(x0(Pos,2),x0(Pos,1),'ok');
colorbar(); 
caxis([0 1]);
colormap jet
title('Realization not calibrated ')
figure(3); 
imagesc(reshape((zref),[nx,ny]));
hold on
plot(x0(Pos,2),x0(Pos,1),'ok');
colorbar(); 
caxis([0 1]);
colormap jet
title('Reference')

%% Graph of variogram along East and South directions


[VarSim]=varioFFT2D_dl( x0(:,[1 2]) , zsim , 1 , 0 , 0 );
[VarSimNotOpt]=varioFFT2D_dl( x0(:,[1 2]) , zsimNotOpt , 1 , 0 , 0 );
[VarRef]=varioFFT2D_dl( x0(:,[1 2]) , zref , 1 , 0 , 0 ); 

%Confidence interval
dimx=nx; dimy=ny;
for i=1:nbsim
    intervaly(i,:)=VarSim{i,i}(dimx,dimy:2*dimy-1);
    intervaly2(i,:)=VarSimNotOpt{i,i}(dimx,dimy:2*dimy-1);
    intervalx(i,:)=VarSim{i,i}(dimx:2*dimx-1,dimy);
    intervalx2(i,:)=VarSimNotOpt{i,i}(dimx:2*dimx-1,dimy);
end

Iy95=quantile(intervaly,0.95);
Iy05=quantile(intervaly,0.05);
Ix95=quantile(intervalx,0.95);
Ix05=quantile(intervalx,0.05);
I2y95=quantile(intervaly2,0.95);
I2y05=quantile(intervaly2,0.05);
I2x95=quantile(intervalx2,0.95);
I2x05=quantile(intervalx2,0.05);

%East direction
figure(4)
a=zeros(ny,1)';
b=zeros(ny,1)';
for i=1:nbsim
    a=a+VarSim{i,i}(nx,ny:2*ny-1)/nbsim;
    b=b+VarSimNotOpt{i,i}(nx,ny:2*ny-1)/nbsim;
    plot([0 : ny-1],VarSim{i,i}(nx,ny:2*ny-1),'Color',[0.7,0.7,0.7])
    hold on
    plot([0 : ny-1],VarSimNotOpt{i,i}(nx,ny:2*ny-1),'Color',[0.9,0.9,0.9])
    hold on
end
plot([0:dimy-1],Iy95(1:end),'--k','LineWidth',2);
hold on
plot([0:dimy-1],Iy05(1:end),'--k','LineWidth',2);
hold on
plot([0:dimy-1],I2y95(1:end),':k','LineWidth',2);
hold on
plot([0:dimy-1],I2y05(1:end),':k','LineWidth',2);
hold on
plot([0 : ny-1],VarRef{1,1}(nx,ny:2*ny-1),'r','LineWidth',2)
xlabel('Distance h')
ylabel('Variogram value')
%ylim([0  0.15])
xlim([1  ny/2-1])

figure(5)
a=zeros(nx,1);
b=zeros(ny,1)';
for i=1:nbsim
    a=a+VarSim{i,i}(nx:2*nx-1,ny)/nbsim;
    b=b+VarSimNotOpt{i,i}(nx:2*nx-1,ny)/nbsim;
    plot([0 : nx-1],VarSim{i,i}(nx:2*nx-1,ny),'Color',[0.7,0.7,0.7])
    hold on
    plot([0 : nx-1],VarSimNotOpt{i,i}(nx:2*nx-1,ny),'Color',[0.9,0.9,0.9])
    hold on
end
plot([0:dimx-1],Ix95(1:end),'--k','LineWidth',2);
hold on
plot([0:dimx-1],Ix05(1:end),'--k','LineWidth',2);
hold on
plot([0:dimx-1],I2x95(1:end),':k','LineWidth',2);
hold on
plot([0:dimx-1],I2x05(1:end),':k','LineWidth',2);
hold on
plot([0 : nx-1],VarRef{1,1}(nx:2*nx-1,ny),'r','LineWidth',2)
xlabel('Distance h')
ylabel('Variogram value')
%ylim([0  0.15])
xlim([1  nx/2-1])
%% Graph of directional asymmetry along East and South directions

[AssSim]=varioFFT2D_dl( x0(:,[1 2]) , zsim , [8,3] , 0 , 0 );
[AssSimNotOpt]=varioFFT2D_dl( x0(:,[1 2]) , zsimNotOpt , [8,3] , 0 , 0 );
[AssRef]=varioFFT2D_dl( x0(:,[1 2]) , zref , [8,3] , 0 , 0 ); 

%Confidence interval
dimx=nx; dimy=ny;
for i=1:nbsim
    intervaly(i,:)=AssSim{i,i}(dimx,dimy:2*dimy-1);
    intervaly2(i,:)=AssSimNotOpt{i,i}(dimx,dimy:2*dimy-1);
    intervalx(i,:)=AssSim{i,i}(dimx:2*dimx-1,dimy);
    intervalx2(i,:)=AssSimNotOpt{i,i}(dimx:2*dimx-1,dimy);
end

Iy95=quantile(intervaly,0.95);
Iy05=quantile(intervaly,0.05);
Ix95=quantile(intervalx,0.95);
Ix05=quantile(intervalx,0.05);
I2y95=quantile(intervaly2,0.95);
I2y05=quantile(intervaly2,0.05);
I2x95=quantile(intervalx2,0.95);
I2x05=quantile(intervalx2,0.05);

%East direction
figure(6)
a=zeros(ny,1)';
b=zeros(ny,1)';
for i=1:nbsim
    a=a+AssSim{i,i}(nx,ny:2*ny-1)/nbsim;
    b=b+AssSimNotOpt{i,i}(nx,ny:2*ny-1)/nbsim;
    plot([0 : ny-1],AssSim{i,i}(nx,ny:2*ny-1),'Color',[0.7,0.7,0.7])
    hold on
    plot([0 : ny-1],AssSimNotOpt{i,i}(nx,ny:2*ny-1),'Color',[0.9,0.9,0.9])
    hold on
end
plot([0:dimy-1],Iy95(1:end),'--k','LineWidth',2);
hold on
plot([0:dimy-1],Iy05(1:end),'--k','LineWidth',2);
hold on
plot([0:dimy-1],I2y95(1:end),':k','LineWidth',2);
hold on
plot([0:dimy-1],I2y05(1:end),':k','LineWidth',2);
hold on
plot([0 : ny-1],AssRef{1,1}(nx,ny:2*ny-1),'r','LineWidth',2)
xlabel('Distance h')
ylabel('Asymmetry value')
ylim([-0.12  0.02])
xlim([1  ny/2-1])

figure(7)
a=zeros(nx,1);
b=zeros(ny,1)';
for i=1:nbsim
    a=a+AssSim{i,i}(nx:2*nx-1,ny)/nbsim;
    b=b+AssSimNotOpt{i,i}(nx:2*nx-1,ny)/nbsim;
    plot([0 : nx-1],AssSim{i,i}(nx:2*nx-1,ny),'Color',[0.7,0.7,0.7])
    hold on
    plot([0 : nx-1],AssSimNotOpt{i,i}(nx:2*nx-1,ny),'Color',[0.9,0.9,0.9])
    hold on
end
plot([0:dimx-1],Ix95(1:end),'--k','LineWidth',2);
hold on
plot([0:dimx-1],Ix05(1:end),'--k','LineWidth',2);
hold on
plot([0:dimx-1],I2x95(1:end),':k','LineWidth',2);
hold on
plot([0:dimx-1],I2x05(1:end),':k','LineWidth',2);
hold on
plot([0 : nx-1],AssRef{1,1}(nx:2*nx-1,ny),'r','LineWidth',2)
xlabel('Distance h')
ylabel('Asymmetry value')
ylim([-0.02  0.01])
xlim([1  nx/2-1])

